package com.example.loginpage

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class signup : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_signup)

        val buttonSignUp: Button = findViewById(R.id.buttonSignUp)
        val editTextFullName: EditText = findViewById(R.id.editTextFullNameSignUp)
        val editTextEmailSignUp: EditText = findViewById(R.id.editTextEmailSignUp)
        val editTextPasswordSignUp: EditText = findViewById(R.id.editTextPasswordSignUp)

        buttonSignUp.setOnClickListener {
            val fullName = editTextFullName.text.toString()
            val email = editTextEmailSignUp.text.toString()
            val password = editTextPasswordSignUp.text.toString()

            // Dummy validation: Check if all fields are non-empty
            if (fullName.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty()) {
                // Navigate to HomeActivity (dummy action)
                val intent = Intent(this, newpage::class.java)
                startActivity(intent)
            } else {
                // Show error message (dummy action)
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }

    }
}
package com.example.loginpage

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId", "SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)


        val buttonLogin: Button = findViewById(R.id.buttonLogin)
        val editTextEmailLogin: EditText = findViewById(R.id.editTextEmailLogin)
        val editTextPasswordLogin: EditText = findViewById(R.id.editTextPasswordLogin)

            buttonLogin.setOnClickListener{
                val email = editTextEmailLogin.text.toString()
                val password = editTextPasswordLogin.text.toString()


                if ( email.isNotEmpty() && password.isNotEmpty()) {

                    val intent = Intent(this, newpage::class.java)
                    startActivity(intent)
                } else {
                    // Show error message
                    Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                }
        }
        val text: TextView = findViewById(R.id.textViewSignUp)
            text.setOnClickListener{
                val intent = Intent(this, signup::class.java)
                startActivity(intent)
        }

    }
}
